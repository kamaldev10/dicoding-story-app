export const footerView = {
  async render() {
    return `
        
    <footer class="bg-gray-800 text-white py-12">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="mb-6 md:mb-0">
                    <h3 class="text-2xl font-bold" x-data="{ appName: 'YourApp' }" x-text="appName"></h3>
                    <p class="mt-2 text-gray-400">Creating digital experiences that matter.</p>
                </div>
                <div class="flex space-x-6">
                    <a href="#" class="hover:text-blue-400 transition duration-300">
                        <i class="fab fa-twitter text-xl"></i>
                    </a>
                    <a href="#" class="hover:text-blue-400 transition duration-300">
                        <i class="fab fa-facebook-f text-xl"></i>
                    </a>
                    <a href="#" class="hover:text-blue-400 transition duration-300">
                        <i class="fab fa-instagram text-xl"></i>
                    </a>
                    <a href="#" class="hover:text-blue-400 transition duration-300">
                        <i class="fab fa-linkedin-in text-xl"></i>
                    </a>
                </div>
            </div>
            <hr class="border-gray-700 my-8">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <p class="text-gray-400">© 2025 YourApp. All rights reserved.</p>
                <div class="mt-4 md:mt-0">
                    <ul class="flex space-x-6">
                        <li><a href="#" class="text-gray-400 hover:text-white transition duration-300">Privacy Policy</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition duration-300">Terms of Service</a></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition duration-300">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
        `;
  },

  async afterRender() {
    document.addEventListener("DOMContentLoaded", function () {
      // Form submission handler
      const contactForm = document.getElementById("contactForm");
      if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
          event.preventDefault();
          alert("Thank you for your message! We will get back to you soon.");
          contactForm.reset();
        });
      }

      // Smooth scrolling for anchor links
      document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
        anchor.addEventListener("click", function (e) {
          e.preventDefault();

          const targetId = this.getAttribute("href");
          const targetElement = document.querySelector(targetId);

          if (targetElement) {
            window.scrollTo({
              top: targetElement.offsetTop,
              behavior: "smooth",
            });
          }
        });
      });

      // Add your personal information
      // You can change these values to customize the page
      document.querySelector(
        "[x-data=\"{ name: 'John Doe' }\"]"
      ).__x.$data.name = "John Doe";
      document.querySelector(
        "[x-data=\"{ role: 'Software Developer & UI/UX Designer' }\"]"
      ).__x.$data.role = "Software Developer & UI/UX Designer";
      document.querySelector(
        "[x-data=\"{ tagline: 'Creating intuitive digital experiences that solve real-world problems.' }\"]"
      ).__x.$data.tagline =
        "Creating intuitive digital experiences that solve real-world problems.";
      document.querySelector(
        "[x-data=\"{ bio: 'I am a passionate developer with 5+ years of experience creating user-centered digital solutions. My journey in technology started when I built my first website at age 15, and I've been hooked ever since. I specialize in creating intuitive, accessible, and responsive web applications that solve real problems for real people.' }\"]"
      ).__x.$data.bio =
        "I am a passionate developer with 5+ years of experience creating user-centered digital solutions. My journey in technology started when I built my first website at age 15, and I've been hooked ever since. I specialize in creating intuitive, accessible, and responsive web applications that solve real problems for real people.";
      document.querySelector(
        "[x-data=\"{ appName: 'YourApp' }\"]"
      ).__x.$data.appName = "YourApp";
    });
  },
};
