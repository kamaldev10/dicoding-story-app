import CONFIG from "../config";

class AuthApi {
  constructor(baseUrl = CONFIG.BASE_URL) {
    this.baseUrl = baseUrl;
  }

  async register({ name, email, password }) {
    try {
      const response = await fetch(`${this.baseUrl}/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, email, password }),
      });

      const result = await response.json();
      return result;
    } catch (error) {
      console.error("Register error:", error);
      return { error: true, message: "Gagal melakukan registrasi" };
    }
  }

  async login({ email, password }) {
    try {
      const response = await fetch(`${this.baseUrl}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });

      const result = await response.json();
      return result;
    } catch (error) {
      console.error("Login error:", error);
      return { error: true, message: "Gagal melakukan login" };
    }
  }
}

export default AuthApi;
