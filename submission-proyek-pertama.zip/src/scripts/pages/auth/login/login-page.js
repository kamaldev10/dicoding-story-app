import { LoginPresenter } from "./login-presenter";

const LoginPage = {
  async render() {
    return `
      <div class="min-h-screen flex items-center justify-center bg-gradient-to-r from-blue-400 to-purple-500">
        <div class="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md">
          <h2 class="text-2xl font-bold text-center mb-6">Login</h2>
          <form id="loginForm" class="space-y-4">
            <div>
              <label aria-labelledby="email" class="block text-sm font-medium">Email</label>
              <input id="email" type="email" class="w-full mt-1 p-2 border rounded-md focus:ring focus:ring-blue-300" />
              <p class="text-sm text-red-600 mt-1 hidden" id="error-email"></p>
            </div>
            <div>
              <label aria-labelledby="pasword" class="block text-sm font-medium">Password</label>
              <input id="password" type="password" class="w-full mt-1 p-2 border rounded-md focus:ring focus:ring-blue-300" />
              <p class="text-sm text-red-600 mt-1 hidden" id="error-password"></p>
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">Login</button>
            <p class="text-sm text-center mt-2">Belum punya akun? <a href="#/register" class="text-blue-600">Daftar</a></p>
            <p id="login-error" class="text-center text-red-600 mt-2 hidden"></p>
          </form>
        </div>
      </div>
    `;
  },

  async afterRender() {
    const presenter = new LoginPresenter(this);
    const form = document.querySelector("#loginForm");

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      presenter.login(
        document.querySelector("#email").value,
        document.querySelector("#password").value
      );
    });
  },

  clearErrors() {
    document.querySelector("#error-email").classList.add("hidden");
    document.querySelector("#error-password").classList.add("hidden");
  },

  showError(field, message) {
    const errorEl = document.querySelector(`#error-${field}`);
    errorEl.textContent = message;
    errorEl.classList.remove("hidden");
  },

  setLoadingState(isLoading) {
    const btn = document.querySelector("#loginForm button");
    btn.disabled = isLoading;
    btn.textContent = isLoading ? "Loading..." : "Login";
  },

  showLoginError(message) {
    const errEl = document.querySelector("#login-error");
    errEl.textContent = message;
    errEl.classList.remove("hidden");
  },

  redirectToHome() {
    window.location.hash = "#/";
  },
};

export default LoginPage;
