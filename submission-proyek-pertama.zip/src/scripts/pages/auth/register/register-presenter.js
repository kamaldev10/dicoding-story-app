import AuthApi from "../../../data/auth-api";

export default class RegisterPresenter {
  constructor(view) {
    this.view = view;
    this.api = new AuthApi();
  }

  validate({ name, email, password }) {
    let isValid = true;
    this.view.clearErrors();

    if (!name || name.trim().length < 2) {
      this.view.showError("name", "Nama minimal 2 karakter");
      isValid = false;
    }

    if (!email) {
      this.view.showError("email", "Email wajib diisi");
      isValid = false;
    } else if (!/^\S+@\S+\.\S+$/.test(email)) {
      this.view.showError("email", "Format email tidak valid");
      isValid = false;
    }

    if (!password) {
      this.view.showError("password", "Password wajib diisi");
      isValid = false;
    } else if (password.length < 6) {
      this.view.showError("password", "Password minimal 6 karakter");
      isValid = false;
    }

    return isValid;
  }

  async register({ name, email, password }) {
    if (!this.validate({ name, email, password })) return;

    this.view.setLoadingState(true);

    try {
      const result = await this.api.register({ name, email, password });

      if (result.error) {
        throw new Error(result.message || "Registrasi gagal.");
      }

      this.view.showSuccess("Registrasi berhasil. Silakan login.");
      this.view.resetForm();
    } catch (err) {
      this.view.showRegisterError(err.message);
    } finally {
      this.view.setLoadingState(false);
    }
  }
}
