import RegisterPresenter from "./register-presenter";

const RegisterPage = {
  async render() {
    return `
      <div class="min-h-screen flex items-center justify-center bg-gradient-to-r from-green-400 to-teal-500">
        <div class="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md">
          <h2 class="text-2xl font-bold text-center mb-6">Daftar</h2>
          <form id="registerForm" class="space-y-4">
            <div>
              <label aria-labelledby="name" class="block text-sm font-medium">Nama</label>
              <input id="name" type="text" class="w-full mt-1 p-2 border rounded-md focus:ring focus:ring-green-300" />
              <p class="text-sm text-red-600 mt-1 hidden" id="error-name"></p>
            </div>
            <div>
              <label aria-labelledby="email" class="block text-sm font-medium">Email</label>
              <input id="email" type="email" class="w-full mt-1 p-2 border rounded-md focus:ring focus:ring-green-300" />
              <p class="text-sm text-red-600 mt-1 hidden" id="error-email"></p>
            </div>
            <div>
              <label aria-labelledby="password" class="block text-sm font-medium">Password</label>
              <input id="password" type="password" class="w-full mt-1 p-2 border rounded-md focus:ring focus:ring-green-300" />
              <p class="text-sm text-red-600 mt-1 hidden" id="error-password"></p>
            </div>
            <button type="submit" class="w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700">Daftar</button>
            <p class="text-sm text-center mt-2">Sudah punya akun? <a href="#/login" class="text-green-600">Login</a></p>
            <p id="register-error" class="text-center text-red-600 mt-2 hidden"></p>
            <p id="register-success" class="text-center text-green-600 mt-2 hidden"></p>
          </form>
        </div>
      </div>
    `;
  },

  async afterRender() {
    const presenter = new RegisterPresenter(this);
    const form = document.querySelector("#registerForm");

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      presenter.register(
        document.querySelector("#name").value,
        document.querySelector("#email").value,
        document.querySelector("#password").value
      );
    });
  },

  clearErrors() {
    ["name", "email", "password"].forEach((field) => {
      document.querySelector(`#error-${field}`).classList.add("hidden");
    });
  },

  showError(field, message) {
    const errorEl = document.querySelector(`#error-${field}`);
    errorEl.textContent = message;
    errorEl.classList.remove("hidden");
  },

  setLoadingState(isLoading) {
    const btn = document.querySelector("#registerForm button");
    btn.disabled = isLoading;
    btn.textContent = isLoading ? "Loading..." : "Daftar";
  },

  showRegisterError(message) {
    const errEl = document.querySelector("#register-error");
    errEl.textContent = message;
    errEl.classList.remove("hidden");
  },

  showRegisterSuccess(message) {
    const successEl = document.querySelector("#register-success");
    successEl.textContent = message;
    successEl.classList.remove("hidden");
  },

  redirectToLogin() {
    setTimeout(() => {
      window.location.hash = "/login";
    }, 1500);
  },
};

export default RegisterPage;
