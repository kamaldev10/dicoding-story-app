import { StoryApi } from "../../data/story-api";

export class HomePresenter {
  constructor(view, token) {
    this.view = view;
    this.token = token;
    this.currentPage = 1;
    this.filterLocation = false;
    this.stream = null;
    this.map = null;
    this.marker = null;
  }

  async loadStories() {
    try {
      this.view.showLoading();
      const response = await new StoryApi().getAllStories({
        token: this.token,
        page: this.currentPage,
        location: this.filterLocation ? 1 : 0,
        size: 10,
      });

      this.view.showStories(response.listStory);
      this.view.updatePagination(response.isLastPage, this.currentPage);
    } catch (err) {
      this.view.showError(err.message);
    } finally {
      this.view.hideLoading();
    }
  }

  nextPage() {
    this.currentPage++;
    this.loadStories();
  }

  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.loadStories();
    }
  }

  setLocationFilter(checked) {
    this.filterLocation = checked;
    this.currentPage = 1;
    this.loadStories();
  }

  async submitNewStory({ description, photo, lat, lon }) {
    try {
      this.view.showLoading();
      await new StoryApi().addStory({
        token: this.token,
        description,
        photo,
        lat,
        lon,
      });

      this.view.hideModal();
      this.loadStories();
      this.stopCamera();
    } catch (err) {
      this.view.showModalError(err.message);
    } finally {
      this.view.hideLoading();
    }
  }

  async initCamera(videoElement) {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoElement.srcObject = this.stream;
    } catch (err) {
      console.error("Kamera tidak tersedia:", err);
    }
  }

  stopCamera() {
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }
  }

  initMap({ latInput, lonInput }) {
    if (this.map) {
      this.map.remove();
      this.map = null;
    }

    setTimeout(() => {
      const mapEl = document.getElementById("modal-map");
      if (!mapEl) {
        console.error("Elemen #map tidak ditemukan di DOM");
        return;
      }

      this.map = L.map(mapEl).setView([-6.2, 106.8], 13);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(
        this.map,
      );

      this.map.on("click", (e) => {
        const { lat, lng } = e.latlng;
        if (this.marker) {
          this.marker.setLatLng(e.latlng);
        } else {
          this.marker = L.marker(e.latlng).addTo(this.map);
        }
        latInput.value = lat;
        lonInput.value = lng;
      });
    }, 100);
  }
}
