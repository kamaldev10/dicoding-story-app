import { HomeView } from "./home-view.js";
import { CameraUtils } from "../../utils/camera-utils.js";
import { HomePresenter } from "./home-presenter.js";

const HomePage = {
  async render() {
    return `
      <section id="homepage" class="min-h-screen w-full bg-white">
        <!-- Header & tombol add story -->
        <div class="flex justify-between items-center my-4">
          <h1 class="text-2xl font-bold">Stories</h1>
          <button id="add-story" class="bg-gray-500 text-white px-4 py-2 rounded"><i class="fa-solid fa-plus"></i>Add Story</button>
        </div>

        <!-- Filter lokasi -->
        <div class="mb-4">
          <label class="flex items-center space-x-2">
            <input type="checkbox" id="filter-location" />
            <span>Hanya tampilkan cerita dengan lokasi</span>
          </label>
        </div>

        <!-- List cerita -->
        <div id="story-list" class="max-w-lg mx-auto gap-2 bg-gradient-to-r from-cyan-700 to-cyan-300 rounded-xl shadow-md overflow-hidden md:max-w-2xl px-8 py-5 my-5"></div>

        <!-- Pagination -->
        <div id="pagination" class="mt-6 flex justify-between">
          <button id="prev-page" class="px-4 py-2 border-solid border-2 border-cyan-500 rounded">Previous</button>
          <button id="next-page" class="px-4 py-2 border-solid border-2 border-cyan-500 rounded">Next</button>
        </div>

        <!-- Loading dan error -->
        <div id="loading" class="mt-4 text-gray-500 hidden">Loading...</div>
        <div id="error-message" class="mt-2 text-red-600"></div>

        <!-- Modal -->
        <div id="modal-overlay" class="fixed inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50 overflow-y-auto">
          <div class="bg-white w-full max-w-md p-6 rounded-lg shadow-lg relative">
            <h2 class="text-xl font-bold mb-4">Tambah Cerita</h2>
            <form id="add-story-form" class="space-y-4">
              <div>
                <label class="block font-medium">Deskripsi</label>
                <textarea name="description" required class="w-full border px-3 py-2 rounded" rows="3"id="text-area"></textarea>
              </div>
 
              <div>
                <label class="block font-medium">Ambil Foto</label>
                <video id="camera-stream" class="w-full rounded mb-2" autoplay></video>
                <img id="photo-preview" class="w-full rounded mb-2 hidden" alt="Preview hasil foto" />
                <div class="flex gap-2">
                  <button type="button" id="capture-btn" class="bg-green-600 text-white px-4 py-1 rounded mb-2">Ambil Foto</button>
                  <button type="button" id="recapture-btn" class="bg-yellow-500 text-white px-4 py-1 rounded mb-2 hidden">Ulangi</button>
                </div>
                <canvas aria-labelledby="photo" id="photo-canvas" class="hidden"></canvas>
                <input type="file" name="photo" id="photo-input" accept="image/*" required class="w-full" />
                <p class="text-sm text-gray-500">Atau pilih file manual.</p>
              </div>

              <div>
                <label aria-labelledby="modal-map" class="block font-medium mb-1">Pilih Lokasi (opsional)</label>
                <div id="modal-map" class="h-52 rounded border mb-2"></div>
                <input type="hidden" name="lat" />
                <input type="hidden" name="lon" />
                <p class="text-sm text-gray-500">Klik peta untuk memilih lokasi.</p>
              </div>

              <div class="flex justify-end gap-2 mt-4">
                <button type="button" id="cancel-modal" class="px-4 py-2 border rounded bg-gray-200">Batal</button>
                <button type="submit" class="bg-cyan-600 text-white px-4 py-2 rounded">Kirim</button>
              </div>

              <p id="modal-error" class="text-red-600 mt-2"></p>
            </form>
          </div>
        </div>
      </section>
    `;
  },

  async afterRender() {
    const token = localStorage.getItem("authToken");
    if (!token) {
      document.getElementById("homepage").innerHTML = ` 
       <div class="mb-6 mt-10 ">
        <i class="fas fa-solid fa-shield-alt text-8xl opacity-90" style="--fa-primary-color: gold;"></i>
      </div>
      <h2 class="text-3xl font-bold mb-4">Akses Terbatas</h2>
       <p class="text-red-500 text-lg leading-relaxed">
      Halaman homepage hanya dapat diakses setelah Anda melakukan login terlebih
      dahulu.
      </p>
      `;
      return;
    }

    const view = new HomeView();
    const presenter = new HomePresenter(view, token);

    view.prevPageBtn.addEventListener("click", () => presenter.prevPage());
    view.nextPageBtn.addEventListener("click", () => presenter.nextPage());

    document
      .getElementById("filter-location")
      .addEventListener("change", (e) => {
        presenter.setLocationFilter(e.target.checked);
      });

    document.getElementById("add-story").addEventListener("click", () => {
      view.showModal();
      presenter.initMap({ latInput: view.latInput, lonInput: view.lonInput });
      CameraUtils.initCamera(view.video);
    });

    document.getElementById("cancel-modal").addEventListener("click", () => {
      view.hideModal();
      presenter.stopCamera();
    });

    view.captureBtn.addEventListener("click", () => {
      CameraUtils.capturePhoto({
        videoEl: view.video,
        canvasEl: view.canvas,
        previewImgEl: view.previewImg,
        photoInputEl: view.photoInput,
        captureBtn: view.captureBtn,
        recaptureBtn: view.recaptureBtn,
      });
    });

    view.recaptureBtn.addEventListener("click", () => {
      CameraUtils.resetCapture({
        videoEl: view.video,
        previewImgEl: view.previewImg,
        photoInputEl: view.photoInput,
        captureBtn: view.captureBtn,
        recaptureBtn: view.recaptureBtn,
      });
    });

    view.form.addEventListener("submit", (e) => {
      e.preventDefault();
      view.modalError.textContent = "";

      const description = view.form.description.value.trim();
      const photo = view.photoInput.files[0];
      const lat = view.latInput.value ? parseFloat(view.latInput.value) : null;
      const lon = view.lonInput.value ? parseFloat(view.lonInput.value) : null;

      if (photo && photo.size > 1024 * 1024) {
        view.showModalError("Ukuran gambar maksimal 1MB.");
        return;
      }

      presenter.submitNewStory({ description, photo, lat, lon });
    });

    presenter.loadStories();
  },
};

export default HomePage;
